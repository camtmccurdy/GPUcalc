package edu.psu.ist261;

public class Main {

	public static void main(String[] args) {
		System.out.println("Success");
                new GUICalc().setVisible(true);
	}

}
